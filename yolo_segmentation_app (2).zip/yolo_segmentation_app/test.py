import requests
url = "http://127.0.0.1:5000/predict"

headers = {
    "API-KEY" : "4973f99a3006f8b98ba832a7ae801a12bef7d85f56fa0c6ff3f6877f193f94e4"
    
}

response = requests.post(url, headers=headers, data = {"image_url":"https://images.pexels.com/photos/210019/pexels-photo-210019.jpeg?cs=srgb&dl=action-asphalt-auto-210019.jpg&fm=jpg"} )

print(response.json())