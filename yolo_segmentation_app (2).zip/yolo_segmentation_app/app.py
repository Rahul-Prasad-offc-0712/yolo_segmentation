from flask import Flask, render_template, request, jsonify, send_from_directory, abort
from ultralytics import YOLO
import requests
import os
from PIL import Image
from io import BytesIO
import shutil
from pathlib import Path
from google.cloud import storage
import json
from dotenv import load_dotenv
import secrets

app = Flask(__name__)

# Load environment variables from .env file
load_dotenv()

# Load the YOLO model
model = YOLO("runs/segment/train7/weights/best.pt")

# Load GCP credentials from environment variables
credentials_dict = {
    'type': os.environ['GOOGLE_CLOUD_STORAGE_TYPE'],
    'project_id': os.environ['GOOGLE_CLOUD_STORAGE_PROJECT_ID'],
    'private_key_id': os.environ['GOOGLE_CLOUD_STORAGE_PRIVATE_KEY_ID'],
    'private_key': os.environ['GOOGLE_CLOUD_STORAGE_PRIVATE_KEY'].replace('\\n', '\n'),
    'client_email': os.environ['GOOGLE_CLOUD_STORAGE_CLIENT_EMAIL'],
    'client_id': os.environ['GOOGLE_CLOUD_STORAGE_CLIENT_ID'],
    'auth_uri': 'https://accounts.google.com/o/oauth2/auth',
    'token_uri': 'https://oauth2.googleapis.com/token',
    'auth_provider_x509_cert_url': 'https://www.googleapis.com/oauth2/v1/certs',
    'client_x509_cert_url': f"https://www.googleapis.com/robot/v1/metadata/x509/{os.environ['GOOGLE_CLOUD_STORAGE_CLIENT_EMAIL']}"
}

with open("gcp_temp_creds.json", "w") as f:
    json.dump(credentials_dict, f)

storage_client = storage.Client.from_service_account_json("gcp_temp_creds.json")
bucket = storage_client.bucket(os.environ['GOOGLE_CLOUD_STORAGE_PROJECT_PDF_MODEL_BUCKET_NAME'].strip("'"))

# API Key for authentication (Add your generated API key here)
VALID_API_KEY = "4973f99a3006f8b98ba832a7ae801a12bef7d85f56fa0c6ff3f6877f193f94e4"

# Middleware to check API key in request header
def check_api_key(func):
    def wrapper(*args, **kwargs):
        api_key = request.headers.get('API-Key')  # Get API key from the header
        if api_key != VALID_API_KEY:
            abort(401, description="Unauthorized: Invalid or missing API Key")  # Reject if API key is invalid
        return func(*args, **kwargs)
    return wrapper

# Function to download image from URL
def download_image(url):
    try:
        response = requests.get(url)
        img = Image.open(BytesIO(response.content)).convert("RGB")
        return img
    except Exception as e:
        print(f"Error downloading image: {e}")
        return None

# Crop object from image
def crop_and_save_object(image, box_tensor, filename):
    x, y, w, h = box_tensor.tolist()
    left = int(x - w / 2)
    top = int(y - h / 2)
    right = int(x + w / 2)
    bottom = int(y + h / 2)
    cropped_image = image.crop((left, top, right, bottom))
    cropped_path = os.path.join("temp", filename)
    os.makedirs("temp", exist_ok=True)
    cropped_image.save(cropped_path)
    return cropped_path

# Home route
@app.route('/')
def index():
    return render_template('index.html')

# Prediction route
@app.route('/predict', methods=['POST'])
@check_api_key  # Apply the API key validation here
def predict():
    image_url = request.form['image_url']
    image = download_image(image_url)
    if image is None:
        return jsonify({"error": "Invalid image URL."}), 400

    results = model.predict(
        source=image,
        save=True,
        project="runs/segment/train7",
        name="predict",
        exist_ok=True
    )

    save_dir = "runs/segment/train7/predict"
    prediction_data = []

    for result in results:
        pred_image_path = Path(result.save_dir) / Path(result.path).name
        if not os.path.exists(pred_image_path):
            continue

        # Upload prediction image to GCP
        pred_blob_name = f"predicted/{Path(pred_image_path).name}"
        blob = bucket.blob(pred_blob_name)
        blob.upload_from_filename(pred_image_path)
        pred_url = f"https://storage.googleapis.com/{bucket.name}/{pred_blob_name}"

        for i, box in enumerate(result.boxes.xywh):
            class_id = int(result.boxes.cls[i].item())
            class_name = result.names[class_id]
            confidence = result.boxes.conf[i].item()

            cropped_filename = f"cropped_{class_name}_{i}.jpg"
            cropped_path = crop_and_save_object(image, box, cropped_filename)

            # Upload cropped image
            crop_blob_name = f"cropped_objects/{cropped_filename}"
            crop_blob = bucket.blob(crop_blob_name)
            crop_blob.upload_from_filename(cropped_path)
            crop_url = f"https://storage.googleapis.com/{bucket.name}/{crop_blob_name}"

            prediction_data.append({
                "class": class_name,
                "confidence": confidence,
                "coordinates": box.tolist(),
                "cropped_image_url": crop_url,
                "full_prediction_image_url": pred_url
            })

    return jsonify(prediction_data)

if __name__ == '__main__':
    app.run(debug=True)
