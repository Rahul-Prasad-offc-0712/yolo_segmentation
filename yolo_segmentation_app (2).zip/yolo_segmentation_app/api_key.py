import secrets

# Generate a random API key (32 characters long)
api_key = secrets.token_hex(32)  # 16 bytes = 32 characters
print("Your new API Key:", api_key)
